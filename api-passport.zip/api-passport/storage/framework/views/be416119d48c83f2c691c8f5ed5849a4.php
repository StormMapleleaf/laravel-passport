<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>江汉大学授权中心 - 授权</title>

    <!-- Styles -->
    <link href="<?php echo e(asset('/css/app.css')); ?>" rel="stylesheet">

    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-color: #f5f5f5;
        }

        .passport-authorize .container {
            margin-top: 30px;
            max-width: 600px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }

        .passport-authorize .card-header {
            text-align: center;
            font-size: 24px;
            font-weight: bold;
            padding: 15px;
        }

        .passport-authorize .card-body {
            text-align: center;
        }

        .passport-authorize .scopes {
            margin-top: 20px;
            text-align: left;
        }

        .passport-authorize .buttons {
            margin-top: 25px;
            display: flex;
            justify-content: center;
        }

        .passport-authorize .btn {
            width: 125px;
            margin: 0 10px;
        }

        .passport-authorize .btn-approve {
            margin-right: 15px;
        }
    </style>
</head>
<body class="passport-authorize">
    <div class="container">
        <div class="card card-default">
            <div class="card-header">
                江汉大学授权中心
            </div>
            <div class="card-body">
                <!-- Introduction -->
                <p><strong><?php echo e($client->name); ?></strong> 请求访问您的账户。</p>

                <!-- Scope List -->
                <?php if(count($scopes) > 0): ?>
                    <div class="scopes">
                        <p><strong>该应用将能够：</strong></p>
                        <ul>
                            <?php $__currentLoopData = $scopes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scope): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($scope->description); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <div class="buttons">
                    <!-- Authorize Button -->
                    <form method="post" action="<?php echo e(route('passport.authorizations.approve')); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="state" value="<?php echo e($request->state); ?>">
                        <input type="hidden" name="client_id" value="<?php echo e($client->getKey()); ?>">
                        <input type="hidden" name="auth_token" value="<?php echo e($authToken); ?>">
                        <button type="submit" class="btn btn-success btn-approve">授权</button>
                    </form>

                    <!-- Cancel Button -->
                    <form method="post" action="<?php echo e(route('passport.authorizations.deny')); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <input type="hidden" name="state" value="<?php echo e($request->state); ?>">
                        <input type="hidden" name="client_id" value="<?php echo e($client->getKey()); ?>">
                        <input type="hidden" name="auth_token" value="<?php echo e($authToken); ?>">
                        <button class="btn btn-danger">取消</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
<?php /**PATH D:\github\laravel-passport\api-passport\resources\views/vendor/passport/authorize.blade.php ENDPATH**/ ?>