@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
        <div class="text-center mb-4">
                <!-- Logo 图片 -->
                <img src="{{ asset('jhun.png') }}" alt="Logo" style="max-width: 150px; height: auto;">
            </div>
            <div class="card">
                <div class="card-header">{{ __('欢迎进入江汉大学授权认证中心') }}</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    {{ __('登陆成功!') }}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
